package org.ikasan.studio.core;

import org.ikasan.studio.core.generation.JavaSourceNames;
import org.ikasan.studio.core.metapack.loading.ClasspathDirectoryScanner;
import org.ikasan.studio.core.metapack.model.ComponentPropertyMeta;
import org.ikasan.studio.core.model.ikasan.instance.BasicElement;
import org.ikasan.studio.core.model.ikasan.instance.ComponentProperty;
import org.ikasan.studio.core.model.ikasan.instance.Flow;
import org.ikasan.studio.core.model.ikasan.instance.Module;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.ikasan.studio.core.metapack.model.ComponentPropertyMeta.*;

/**
 * Studio Utils
 */
public class StudioBuildUtils {
    // Enforce as a utility only class
    private StudioBuildUtils() {}

    /**
     * Called only from componentFactory_en.ftl (both V3.3.9 and V4.1.6) via the {@code statics} binding, which
     * static-usage analysis can't see - despite the "unused" warning, this is load-bearing there.
     * Given a string delimited by tokens e.g. this.is.my.class.bob then get the last string, bob in this case
     * @param delimiter to use within the string, NOTE that regex is used to split the string, so special characters like '.' will need to be escaped e.g. "\\."
     * @param input string to analyse
     * @return The last stoken of the string or an empty sp
     */
    @SuppressWarnings("unused")
    public static String getLastToken(String delimiter, String input) {
        String returnString = "";
        if (input != null && delimiter != null) {
            String [] tokens = input.split(delimiter, -1);
            if (tokens.length > 0) {
                returnString = tokens[tokens.length-1];
            }
        }
        return returnString;
    }

    /**
     * Called only from componentFactory_en.ftl (both V3.3.9 and V4.1.6) via the {@code statics} binding, which
     * static-usage analysis can't see - despite the "unused" warning, this is load-bearing there.
     * Given a string delimited by tokens e.g. this.is.my.class.bob then get all but the last string, this.is.my.class in this case
     * @param delimiter to use within the string, NOTE that regex is used to split the string, so special characters like '.' will need to be escaped e.g. "\\."
     * @param input string to analyse
     * @return All but the last stoken of the string or an empty sp
     */
    @SuppressWarnings("unused")
    public static String getAllButLastToken(String delimiter, String input) {
        StringBuilder returnString = new StringBuilder();
        if (input != null && delimiter != null) {
            String [] tokens = input.split(delimiter, -1);
            if (tokens.length > 1) {
                returnString.append(tokens[0]);
                for(int ii = 1; ii < tokens.length-1 ; ii++) {
                    returnString.append(".").append(tokens[ii]);
                }
            }
        }
        return returnString.toString();
    }

    /**
     * True when two names generate the same Java class ("Test a.b", "Test a b" and "TestAB" all do), so they cannot
     * both be used within one scope even though the text differs.
     */
    public static boolean sameGeneratedName(final String left, final String right) {
        return left != null && right != null && toPascalCase(left).equals(toPascalCase(right));
    }

    /**
     * The module name as a database folder in the datasource URL. Ikasan's H2 backup service parses that URL as a URI, so
     * a space (or any character that is illegal in a URI path, or that starts H2 settings) stopped the application
     * starting. Only those characters are replaced, so a name that already works keeps exactly the same folder.
     */
    public static String toDatabaseFolderName(final String input) {
        return input == null ? "" : input.replaceAll("[\\s\"<>\\\\^`{|}\\[\\]#%?;\\p{Cntrl}]+", "_");
    }

    /**
     * Used by FTL, don't assume unused.
     * Like camel case but starts with upper case letter
     * @param input to be changed
     * @return pascal case version of input
     */
    public static String toPascalCase(final String input) {
        return toJavaClassName(input);
    }

    /**
     * Convert the supplied string so that it confirms to the naming rules for java classnames
     * @param input string to be converted
     * @return the input string in the form of a java classname
     */
    public static String toJavaClassName(final String input) {
        return JavaSourceNames.toClassName(input);
    }

    /**
     * Used by FTL: converterTemplate_en.ftl and emailConverterTemplate_en.ftl in both bundled packs.
     * FreeMarker invokes this through the {@code StudioBuildUtils} statics binding.
     * <p>
     * A fromType/toType property is free text, and its help/tooltip text is drawn from the same engine that
     * describes an upstream component's Output: for humans (see ComponentMeta#getEffectiveOutputTypeDescription) -
     * that description can carry a trailing explanatory annotation e.g. "java.lang.Object (auto-converted)" for a
     * JMS consumer with Auto Content Conversion on. A user copying that display text verbatim into a fromType/
     * toType field would otherwise generate an uncompilable type literal - strip such a trailing "(...)" before
     * using the value as an actual Java type, so the annotation is silently dropped rather than breaking the build.
     * @param input string to be converted
     * @return the input string with any trailing bracketed annotation removed, and surrounding whitespace trimmed
     */
    @SuppressWarnings("unused")
    public static String toJavaTypeLiteral(final String input) {
        if (input == null) {
            return null;
        }
        return input.replaceAll("\\s*\\([^)]*\\)\\s*$", "").trim();
    }

    /**
     * Convert the supplied string so that it confirms to the naming rules for java package names i.e.
     *    no spaces
     *    if there is a leading digit, prepend with _
     * @param input string to be converted
     * @return the input string in the form of a java package
     */
    public static String toJavaPackageName(String input) {
        return JavaSourceNames.toPackageName(input);
    }

    /**
     * Used by FTL: propertiesTemplate_en.ftl in both bundled packs through the
     * {@code StudioBuildUtils} statics binding; also called by the plugin's LaunchBlueAction.
     * <p>
     * Convert the supplied string to url style string i.e.
     *   space and underscore replaced by -
     *   all lower case
     * @param input string to be converted
     * @return the input string in kebab case
     */
    @SuppressWarnings("unused")
    public static String toUrlString(final String input) {
        if (input != null && !input.isEmpty()) {
            // Fold accents and drop anything else non-ASCII: this is a servlet context path, which Spring Boot would
            // misread (it reads .properties as ISO-8859-1) and Studio's own URLs cannot rely on.
            String ascii = java.text.Normalizer.normalize(input, java.text.Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .replaceAll("[^\\x00-\\x7F]", "");
            // Tomcat registers the context path as a JMX object name (a quote, comma, equals, colon, asterisk or question
            // mark there fails startup), and the rest of these break the URLs Studio builds. Treat them as separators.
            String path = ascii
                    .replaceAll("[\"\\\\%?#<>|^`{}\\[\\];,=:*]+", " ")
                    .replaceAll("  +", " ")
                    .replaceAll("[ -]+", "-").toLowerCase(Locale.ROOT);
            return path.isEmpty() ? "module" : path;
        } else {
            return input;
        }
    }

    /**
     * Pretty much what org.apache.commons.text.CaseUtils does i.e. produce camelCase, but we are limited by what libs Intellij
     * pull into the plugin componentDependencies.
     * @param input a string potentially with spaces
     * @return a string that could be used as a java identifier
     */
    public static String toJavaIdentifier(final String input) {
        return JavaSourceNames.toIdentifier(input);
    }

    /**
     * Get the subdirectories of a given directory on the classpath, in JARs or the file system.
     * Retained delegate used by StudioBuildUtilsTest in the root plugin test suite, not by FTL.
     * The scanner closes directory streams but keeps shared JAR file systems open for other resource consumers.
     * @param dir to look through
     * @return a string array of subdirectories
     * @throws URISyntaxException if there were issues
     * @throws IOException if there were issues
     */
    @SuppressWarnings("unused")
    public static String[] getDirectories(final String dir) throws URISyntaxException, IOException {
        return ClasspathDirectoryScanner.getDirectories(dir);
    }

    /**
     * Used by FTL: componentFactory_en.ftl and propertiesTemplate_en.ftl in both bundled packs
     * through the {@code StudioBuildUtils} statics binding.
     * The supplied string template e.g. __flow.ftp.consumer.cron-expression, replacing meta tags so that the final
     * string represents a call to a property e.f. myFlow.ftp.consumer.cron-expression
     * @param module in scope that might relate to this property
     * @param flow in scope that might relate to this property
     * @param ikasanBasicElement in scope that might relate to this property
     * @param template to be updated
     * @return A string representing a property
     */
    @SuppressWarnings("unused")
    public static String substitutePlaceholderInLowerCase(Module module, Flow flow, BasicElement ikasanBasicElement, String template) {
        String propertyLabel = template;
        if (template != null && template.contains(SUBSTITUTION_PREFIX)) {
            if (module != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_MODULE, module.getJavaPackageName());
            }
            if (flow != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_FLOW, flow.getJavaPackageName());
            }
            if (ikasanBasicElement != null ) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_COMPONENT, ikasanBasicElement.getJavaPackageName());
            }
        }
        return propertyLabel;
    }

    /**
     * ** Used by FTL ***
     * The supplied string template e.g. __flow.ftp.consumer.cron-expression, replacing meta tags so that the final
     * string represents a call to a property e.f. myFlow.ftp.consumer.cron-expression
     * @param module in scope that might relate to this property
     * @param flow in scope that might relate to this property
     * @param ikasanBasicElement in scope that might relate to this property
     * @param template to be updated
     * @return A string representing a property
     */
    public static String substitutePlaceholderInPascalCase(Module module, Flow flow, BasicElement ikasanBasicElement, String template) {
        if (template == null) {
            return "";
        }
        String propertyLabel = template;
        if (template.contains(SUBSTITUTION_PREFIX)) {
            if (module != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_MODULE, toPascalCase(module.getIdentity()));
            }
            if (flow != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_FLOW, toPascalCase(flow.getIdentity()));
            }
            if (ikasanBasicElement != null ) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_COMPONENT, toPascalCase(ikasanBasicElement.getIdentity()));
            }
        }
        return propertyLabel;
    }

    /**
     * For the given component, if the value of default is a property placeholder, replace it wuith  real value.
     * @param module that holds the components.
     * @param flow that contains the component.
     * @param ikasanBasicElement itself.
     */
    public static void substituteAllPlaceholderInPascalCase(Module module, Flow flow, BasicElement ikasanBasicElement) {
        for (ComponentProperty componentProperty : ikasanBasicElement.getComponentProperties().values()) {
            String value = componentProperty.getValueString();
            if (value != null && value.startsWith(ComponentPropertyMeta.SUBSTITUTION_FIELD_NAME)) {
                // The Properties UI resolves these defaults from another row. Proposals have no UI rows.
                String[] parts = value.split(ComponentPropertyMeta.SUBSTITUTION_NAME_VALUE_DELIM, 3);
                String source = parts.length > 1 ? ikasanBasicElement.getPropertyValueAsString(parts[1]) : "";
                if (source.isBlank() || ComponentPropertyMeta.isSubstitutionValue(source)) {
                    throw new IllegalArgumentException("Cannot resolve default for " + componentProperty.getMeta().getPropertyName()
                            + ": supply a value for " + (parts.length > 1 ? parts[1] : value));
                }
                String derived = source + (parts.length > 2 ? parts[2] : "");
                componentProperty.setValue(componentProperty.affectsUserImplementedClass() ? toJavaClassName(derived) : derived);
            } else if (ComponentPropertyMeta.isSubstitutionValue(value)) {
                componentProperty.setValue(substitutePlaceholderInPascalCase(module, flow, ikasanBasicElement, value));
            }
            if (componentProperty.getMeta().getDefaultValue() != null && ComponentPropertyMeta.isSubstitutionValue(componentProperty.getMeta().getDefaultValue().toString())) {
                ComponentPropertyMeta newMeta = componentProperty.getMeta().toBuilder().build();
                componentProperty.setMeta(newMeta);
                newMeta.setDefaultValue(StudioBuildUtils.substitutePlaceholderInPascalCase(module, flow, ikasanBasicElement, newMeta.getDefaultValue().toString()));
            }
        }
    }

    /**
     * Called only from componentFactory_en.ftl (both V3.3.9 and V4.1.6) via the {@code statics} binding, which
     * static-usage analysis can't see - despite the "unused" warning, this is load-bearing there.
     * The supplied string template e.g. __flow.ftp.consumer.cron-expression, replacing meta tags so that the final
     * string represents a call to a property e.f. myFlow.ftp.consumer.cron-expression
     * @param module in scope that might relate to this property
     * @param flow in scope that might relate to this property
     * @param ikasanBasicElement in scope that might relate to this property
     * @param template to be updated
     * @return A string representing a property
     */
    @SuppressWarnings("unused")
    public static String substitutePlaceholderInJavaCamelCase(Module module, Flow flow, BasicElement ikasanBasicElement, String template) {
        String propertyLabel = template;
        if (template != null && template.contains(SUBSTITUTION_PREFIX)) {
            if (module != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_MODULE, module.getJavaVariableName());
            }
            if (flow != null) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_FLOW, flow.getJavaVariableName());
            }
            if (ikasanBasicElement != null ) {
                propertyLabel = propertyLabel.replace(SUBSTITUTION_PREFIX_COMPONENT, ikasanBasicElement.getJavaVariableName());
            }
            // By replacing _ with space, we should get UpperCase after the space, and space removed.
            propertyLabel = propertyLabel.replace("-", " ");
            propertyLabel = StudioBuildUtils.toJavaIdentifier(propertyLabel);
        }
        return propertyLabel;
    }

    /**
     * Called only from componentFactory_en.ftl (both V3.3.9 and V4.1.6) via the {@code statics} binding, which
     * static-usage analysis can't see - despite the "unused" warning, this is load-bearing wherever a Long or
     * CLASS_LITERAL property value is emitted as a Java literal.
     * Java does not auto-box a bare int literal into a Long parameter (e.g. ".setMinAge(120)" fails to compile with
     * "incompatible types: int cannot be converted to Long" - ".setMinAge(120L)" is required). This appends the "L"
     * suffix whenever the property's declared type is java.lang.Long, regardless of the runtime type of the value
     * actually stored (which may be a plain Integer, e.g. from a test fixture or a small persisted number).
     * @param meta of the property whose value is about to be emitted as a Java literal
     * @param valueString the literal text about to be emitted as a Java method argument
     * @return valueString, with an "L" suffix appended when the property's declared type is java.lang.Long
     */
    @SuppressWarnings("unused")
    public static String toJavaLiteral(ComponentPropertyMeta meta, String valueString) {
        if (meta != null && meta.getPropertyDataType() == Long.class && valueString != null && !valueString.isBlank()) {
            return valueString + "L";
        }
        // A property the user fills in as a fully-qualified class name (e.g. "com.example.MyPojo"), but whose
        // real setter takes a java.lang.Class literal (e.g. ObjectToXmlStringConverterBuilder#setObjectClass(Class)),
        // not a String - CLASS_LITERAL is a marker usageDataType (like "configurationDefined") that tells the
        // template to append ".class" so the emitted argument is a real Class literal instead of a bare/quoted name.
        if (meta != null && ComponentPropertyMeta.CLASS_LITERAL.equals(meta.getUsageDataType()) && valueString != null && !valueString.isBlank()) {
            return valueString + ".class";
        }
        return valueString;
    }

    /**
     * Turn the comma seperated string and turn to list
     * @param commaSeperatedList to convert
     * @return List representing input string
     */
    public static List<String> stringToList(String commaSeperatedList) {
        List<String> returnList = new ArrayList<>();

        if (commaSeperatedList != null) {
            // Support a legacy List.toString wrapper, but never strip brackets inside entries.
            if (commaSeperatedList.startsWith("[") && commaSeperatedList.endsWith("]")) {
                commaSeperatedList = commaSeperatedList.substring(1, commaSeperatedList.length() - 1);
            }
            List<String> rawList = Arrays.asList(commaSeperatedList.split("\\s*,\\s*"));
            // LinkedHashSet keeps first-seen order: the user's ordering must survive de-duplication.
            Set<String> deduplicate = new LinkedHashSet<>(rawList);
            if (rawList.size() > deduplicate.size()) {
                returnList = new ArrayList<>(deduplicate);
            } else {
                returnList = rawList;
            }
        }
        return returnList;
    }

    /**
     * When generating the properties file, there is a multi-lined string containing name value pairs.
     * This method turns that string into a map, exposing application generated application properties for reuse
     * inside the plugin.
     * @param multiLineString containing the name valie pairs
     * @return a name value pair containing the properties defined in the input.
     */
    public static Map<String, String> convertStringToMap(String multiLineString) {
        Map<String, String> map = new HashMap<>();
        if (multiLineString != null && multiLineString.length() > 2) {
            // Split the string by new lines
            String[] lines = multiLineString.split("\\R");
            for (String line : lines) {
                int firstEquals = line.indexOf("=");
                // Split each line by the equals sign
                if (firstEquals > 0 && !line.startsWith("#")) {
                    String name = line.substring(0, firstEquals);
                    String value = line.substring(firstEquals + 1);
                    map.put(name.trim(), value.trim());
                }
            }
        }
        // Now attempt to replace placeholders with values
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String value = entry.getValue();
            List<String> placeHolders = extractLabels(value);
            for(String label : placeHolders) {
                String lookupValue = map.get(label);
                if (lookupValue != null) {
                    value = value.replace("${"+label+"}", lookupValue);
                }
            }
            entry.setValue(value);
        }

        return map;
    }

    /**
     * Escape a flow name used inside Spring Boot's map-style application.properties key.
     * Called only from propertiesTemplate_en.ftl (both V3.3.9 and V4.1.6) via the {@code statics} binding,
     * which static-usage analysis can't see - despite the "unused" warning, this is load-bearing for any
     * flow whose name contains a space.
     */
    @SuppressWarnings("unused")
    public static String escapeSpringPropertiesMapKey(String value) {
        return value == null ? "" : escapeNonAscii(value.replace("\\", "\\\\").replace(" ", "\\ "));
    }

    /**
     * Spring Boot reads .properties files as ISO-8859-1, but Studio writes them as UTF-8. A raw non-ASCII character
     * (an accented directory name, Japanese text) would therefore arrive at runtime as mojibake with no error, so
     * write it as a \\uXXXX escape, which the properties loader decodes correctly in any charset. Printable ASCII is
     * untouched, so ordinary values are unchanged.
     */
    private static String escapeNonAscii(String value) {
        StringBuilder result = null;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            boolean escape = c > 0x7e || (c < 0x20 && c != '\n' && c != '\r' && c != '\t');
            if (escape && result == null) {
                result = new StringBuilder(value.length() + 8).append(value, 0, i);
            }
            if (result != null) {
                if (escape) result.append(String.format("\\u%04x", (int) c));
                else result.append(c);
            }
        }
        return result == null ? value : result.toString();
    }

    /**
     * Escape a component property's value before writing it as the right-hand side of a line in
     * application.properties. Called only from propertiesTemplate_en.ftl (both V3.3.9 and V4.1.6) via the
     * {@code statics} binding, which static-usage analysis can't see - despite the "unused" warning, this is
     * load-bearing for any property value containing a backslash (e.g. a filenamePattern regex like ".*\.tmp",
     * or a Windows-style file path). Without it, java.util.Properties' own loader treats an unescaped backslash
     * as the start of an escape sequence: since "\." isn't one of the recognised sequences (backslash, \n, \r,
     * \t, \f, or a unicode escape), it silently drops the backslash and keeps the following character - so a user-entered
     * ".*\.tmp" would come back out at runtime as ".*.tmp", changing the regex's meaning without any error.
     * Unlike escapeSpringPropertiesMapKey, this deliberately does not escape spaces - embedded spaces in a
     * properties value do not need escaping, only backslashes and literal control characters do.
     */
    @SuppressWarnings("unused")
    public static String escapeSpringPropertiesValue(String value) {
        return value == null ? "" : escapeNonAscii(value
                .replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t"));
    }

    /**
     * Given a string that potentially contains placeholders ${label}, attempt to extract the placeholder labels
     * @param input to be examined
     * @return a list of placeholder labels or empty list of there were none
     */
    public static List<String> extractLabels(String input) {
        // Define regex patterns for different placeholder formats and capture the variable name
        String placeholderPattern = "\\$\\{([^}]+)}";
        Pattern pattern = Pattern.compile(placeholderPattern);
        Matcher matcher = pattern.matcher(input);
        List<String> labels = new ArrayList<>();

        // Find and add all labels to the list
        while (matcher.find()) {
            if (matcher.group(1) != null) {
                labels.add(matcher.group(1));
            } else if (matcher.group(2) != null) {
                labels.add(matcher.group(2));
            } else if (matcher.group(3) != null) {
                labels.add(matcher.group(3));
            }
        }

        return labels;
    }

}
