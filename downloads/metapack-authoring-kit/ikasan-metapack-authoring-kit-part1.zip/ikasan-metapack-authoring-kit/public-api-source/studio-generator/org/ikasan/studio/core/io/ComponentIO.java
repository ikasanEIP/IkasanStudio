package org.ikasan.studio.core.io;

import org.ikasan.studio.core.diagnostics.StudioDiagnosticEvent;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.ikasan.studio.StudioRuntimeException;
import org.ikasan.studio.core.StudioBuildException;
import org.ikasan.studio.core.StudioBuildRuntimeException;
import org.ikasan.studio.core.generator.Generator;
import org.ikasan.studio.core.model.ikasan.instance.Flow;
import org.ikasan.studio.core.model.ikasan.instance.Module;
import org.ikasan.studio.core.metapack.model.ComponentTypeMeta;
import org.ikasan.studio.core.metapack.model.IkasanMeta;
import org.ikasan.studio.core.persistence.json.StudioJson;
import org.ikasan.studio.core.persistence.json.IkasanModelDocuments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class ComponentIO {
    private static final ObjectMapper MAPPER = StudioJson.newObjectMapper()
            .enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);
    private static final Logger LOG = LoggerFactory.getLogger(ComponentIO.class);


    /*
     * Deserialize the ComponentTypeMeta at the given path.
     * @param path to the file containing the JSON to deserializes
     * @return an ComponentTypeMeta object representing the deserialized class
     * @throws StudioBuildException to wrap JsonProcessingException
     */
    public static ComponentTypeMeta deserializeComponentTypeMeta(final String path) throws StudioBuildException {
        final String jsonString = getJsonFromFile(path);

        ComponentTypeMeta componentTypeMeta;
        try {
            componentTypeMeta = MAPPER.readValue(jsonString, ComponentTypeMeta.class);
        } catch (JsonProcessingException e) {
            throw new StudioBuildException("The serialised data in [" + path + "] could not be read due to [" + e.getMessage() + "] trace: " + Arrays.toString(e.getStackTrace()));
        }
        return componentTypeMeta;
    }

    /*
     * Deserialize the component at the given path.
     * The component could be any of the child classes of IkasanMeta
     * @param path to the file containing the JSON to deserializes
     * @return an IkasanMeta object representing the deserialized class
     * @throws StudioBuildException  to wrap JsonProcessingException
     */
    public static IkasanMeta deserializeMetaComponent(final String path) throws StudioBuildException {
        final String jsonString = getJsonFromFile(path);

        IkasanMeta ikasanMeta;
        try {
            ikasanMeta = MAPPER.readValue(jsonString, IkasanMeta.class);
        } catch (JsonProcessingException e) {
            throw new StudioBuildException("The serialised data in [" + path + "] could not be read due to [" + e.getMessage() + "] trace: " + Arrays.toString(e.getStackTrace()));
        }
        return ikasanMeta;
    }

    /** Deserializes a strongly typed packaged metadata resource. */
    public static <T> T deserializeResource(final String path, Class<T> type) throws StudioBuildException {
        try {
            return MAPPER.readValue(getJsonFromFile(path), type);
        } catch (JsonProcessingException e) {
            throw new StudioBuildException("The serialised data in [" + path + "] could not be read due to ["
                    + e.getMessage() + "]", e);
        }
    }

    /*
     * Deserialize a module
     * @param path to the file containing the JSON to deserializes
     * @return the deserialized Module
     * @throws StudioBuildException  to wrap JsonProcessingException
     */
    public static Module deserializeModuleInstance(final String path) throws StudioBuildException {
        return deserializeModuleInstanceString(getJsonFromFile(path), path);
    }
    // This interface is easier to test generically
    public static Module deserializeModuleInstanceString(final String jsonString, final String source) throws StudioBuildException {
        Module moduleInstance;
        try {
            moduleInstance = MAPPER.readValue(jsonString, Module.class);
        } catch (JsonProcessingException e) {
            throw new StudioBuildException("The serialised data in [" + source + "] could not be read due to " + e.getMessage() + " trace: " + Arrays.toString(e.getStackTrace()));
        } catch (StudioBuildRuntimeException e) {
            throw new StudioBuildException("The serialised data in [" + source + "] is not safe to load: " + e.getMessage(), e);
        } catch (RuntimeException e) {
            // A structure the deserializer did not expect (for example a missing component name or a number where
            // text is required) escapes as a raw NullPointerException/ClassCastException. Callers only run their safe
            // recovery (preserve the file, disable saves, tell the user) for a StudioBuildException.
            throw new StudioBuildException("The serialised data in [" + source + "] is damaged or has an unexpected structure and could not be read ("
                    + e.getClass().getSimpleName() + "). Correct the file and reload; nothing has been changed.", e);
        }
        return moduleInstance;
    }

    private static String getJsonFromFile(final String path) throws StudioBuildException {
        try (InputStream inputStream = org.ikasan.studio.core.metapack.loading.MetaPackResources.open(path)) {
            if (inputStream == null) {
                throw new StudioBuildException("The serialised data in [" + path + "] could not be loaded, check the path is correct");
            }
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (java.io.IOException e) {
            throw new StudioBuildException("Could not read metadata resource " + path, e);
        }
    }

    /**
     * Convert the supplied java Object into its JSON representation
     * @param value to be turned to JSON
     * @return the Object in JSON format.
     */
    public static String toJson(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            LOG.warn(StudioDiagnosticEvent.format(StudioDiagnosticEvent.Event.CONFIGURATION_INVALID, e, null, null, null));
            throw new StudioRuntimeException(
                    "The Studio model could not be converted to JSON. The existing model.json has not been changed.", e);
        }
    }

    /**
     * Validates the internal adapter JSON used by engine operations and legacy-compatible APIs.
     * Project persistence uses {@link org.ikasan.studio.core.generator.ModelTemplate#create(Module)},
     * which separates this representation into Ikasan module/configuration and Studio documents.
     */
    public static String toValidatedModuleJson(Module module) {
        if (module == null) {
            throw new StudioRuntimeException("The Studio model is not available. The existing model.json has not been changed.");
        }
        String json = toJson(module);
        try {
            validatePersistedModuleJson(json, "in-memory model validation", false);
            return json;
        } catch (StudioBuildException e) {
            throw new StudioRuntimeException("The generated JSON failed validation. The existing model.json has not been changed.", e);
        }
    }
    /**
     * The deserializer tolerates and drops anything it does not recognise, so a container of the wrong JSON type (for
     * example flows: "x") used to load as an empty design and the next save overwrote the file with the truncated
     * result. Reject those instead. Absent, null and empty values are still accepted: they are what the deserializer
     * has always read as "nothing here".
     */
    private static void requireWellShapedContainers(JsonNode root, String source) throws StudioBuildException {
        requireType(root, Generator.FLOWS_TAG, "an array", JsonNode::isArray, "", source);
        JsonNode flows = root.get(Generator.FLOWS_TAG);
        if (flows == null || !flows.isArray()) return;
        for (int flowIndex = 0; flowIndex < flows.size(); flowIndex++) {
            JsonNode flow = flows.get(flowIndex);
            String flowPath = "/" + Generator.FLOWS_TAG + "/" + flowIndex;
            if (flow.isNull()) continue;
            if (!flow.isObject()) throw shapeError(flowPath, "an object", source);
            requireType(flow, Flow.CONSUMER_JSON_TAG, "an object", JsonNode::isObject, flowPath, source);
            requireType(flow, Flow.EXCEPTION_RESOLVER_JSON_TAG, "an object", JsonNode::isObject, flowPath, source);
            JsonNode resolver = flow.get(Flow.EXCEPTION_RESOLVER_JSON_TAG);
            if (resolver != null && resolver.isObject()) {
                // Each entry maps a caught exception to its resolution. One that is not a populated object loads but can
                // never be saved again, which would leave the user unable to save anything.
                for (java.util.Map.Entry<String, JsonNode> entry : resolver.properties()) {
                    if (!entry.getValue().isObject() || entry.getValue().isEmpty()) {
                        throw shapeError(flowPath + "/" + Flow.EXCEPTION_RESOLVER_JSON_TAG + "/" + entry.getKey(),
                                "a populated object", source);
                    }
                }
            }
            for (String arrayTag : new String[]{Flow.FLOW_ELEMENTS_JSON_TAG, Flow.TRANSITIONS_JSON_TAG}) {
                requireType(flow, arrayTag, "an array", JsonNode::isArray, flowPath, source);
                JsonNode items = flow.get(arrayTag);
                if (items == null || !items.isArray()) continue;
                for (int i = 0; i < items.size(); i++) {
                    if (!items.get(i).isObject()) throw shapeError(flowPath + "/" + arrayTag + "/" + i, "an object", source);
                }
            }
        }
    }

    private static void requireType(JsonNode parent, String field, String expected,
                                    java.util.function.Predicate<JsonNode> isExpected, String parentPath,
                                    String source) throws StudioBuildException {
        JsonNode value = parent.get(field);
        if (value != null && !value.isNull() && !isExpected.test(value)) {
            throw shapeError(parentPath + "/" + field, expected, source);
        }
    }

    private static StudioBuildException shapeError(String path, String expected, String source) {
        return new StudioBuildException("The serialised data in [" + source + "] is damaged: " + path + " must be "
                + expected + ". Correct the file and reload; nothing has been changed.");
    }

    /** Validates JSON shape and the minimum identity required for a configured Studio module. */
    public static Module validatePersistedModuleJson(String json, String source, boolean allowEmptyBootstrap)
            throws StudioBuildException {
        // UTF-8 files decoded to String (and pasted text) can retain a leading byte-order mark.
        // Strip only that prefix; U+FEFF inside a JSON string is legitimate model content.
        if (json != null && json.startsWith("\uFEFF")) json = json.substring(1);
        final JsonNode root;
        try {
            root = IkasanModelDocuments.toLegacy(MAPPER.readTree(json));
        } catch (java.io.IOException e) {
            throw new StudioBuildException("The serialised data in [" + source + "] is not valid JSON: " + e.getMessage(), e);
        }
        if (root == null || !root.isObject()) {
            throw new StudioBuildException("The serialised data in [" + source + "] must be a JSON object");
        }
        if (root.isEmpty()) {
            if (allowEmptyBootstrap) {
                return Module.getDumbModuleVersion();
            }
            throw new StudioBuildException("The serialised data in [" + source + "] is an empty bootstrap model, not a configured module");
        }
        requireWellShapedContainers(root, source);
        Module module = deserializeModuleInstanceString(json, source);
        if (!module.isInitialised()) {
            // ModuleDeserializer itself already substitutes a dumb module whenever the persisted JSON has no
            // "version" field at all - the signature of a freshly scaffolded project (e.g. from an archetype)
            // that can have a few top-level fields already filled in (name, applicationPackageName) but hasn't
            // been configured in Studio yet. Same "nothing to load yet" state as a literally empty {} above,
            // not a corrupted model - unlike any other kind of partial/incomplete data, which still fails below.
            if (allowEmptyBootstrap && Module.DUMB_MODULE_VERSION.equals(module.getVersion())) {
                return module;
            }
            throw new StudioBuildException("The serialised data in [" + source + "] is missing required configured-module fields");
        }
        return module;
    }
}
