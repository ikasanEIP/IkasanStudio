package org.ikasan.studio.core.importer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.ikasan.studio.core.StudioBuildException;
import org.ikasan.studio.core.io.ComponentIO;
import org.ikasan.studio.core.metapack.ComponentLibrary;
import org.ikasan.studio.core.metapack.model.ComponentMeta;
import org.ikasan.studio.core.model.ikasan.instance.Module;

import java.util.*;

/**
 * Adapts Ikasan's runtime topology and separate ConfigurationMetaData JSON to a Studio design.
 * Never loads classes named by the input. Original documents are retained as inert JSON;
 * only configuration fields explicitly declared by the selected meta-pack are applied.
 */
public final class IkasanRuntimeImport {
    public static final String SOURCE_FIELD = "ikasanRuntimeImport";
    private static final ObjectMapper JSON = new ObjectMapper().enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);
    private static final int MAX_JSON_LENGTH = 8 * 1024 * 1024;

    private IkasanRuntimeImport() { }

    /** Result is a validated Studio document plus review messages, without configuration values. */
    public record Result(String studioJson, List<String> review) {
        public Result { review = List.copyOf(review); }
    }

    /** A runtime implementation can correspond to several design-time variants (for example scheduled/file consumers). */
    public record ComponentRef(String flow, String component) { }
    public record MappingChoice(ComponentRef component, List<String> variants) { }

    public record PackRecommendation(String pack, String sourceVersion, String targetVersion) {
        public boolean exact() { return sourceVersion.equals(targetVersion); }
    }

    /** Exact version first, otherwise the nearest newer stable patch in the same major/minor line. */
    public static Optional<PackRecommendation> recommendPack(String moduleJson, List<String> packs)
            throws StudioBuildException {
        try {
            String source = read(moduleJson).path("ikasanVersion").asText("");
            if (source.isBlank()) return Optional.empty();
            PackRecommendation nearest = null;
            for (String pack : packs) {
                String target = ComponentLibrary.getMetaPackManifest(pack).ikasanVersion();
                var candidate = new PackRecommendation(pack, source, target);
                if (candidate.exact()) return Optional.of(candidate);
                if (forwardPatch(source, target) && (nearest == null
                        || patch(target).compareTo(patch(nearest.targetVersion())) < 0)) nearest = candidate;
            }
            return Optional.ofNullable(nearest);
        } catch (StudioBuildException failure) { throw failure; }
        catch (Exception failure) { throw new StudioBuildException("Cannot inspect the export's Ikasan version.", failure); }
    }

    private static boolean forwardPatch(String source, String target) {
        if (!source.matches("[0-9]+\\.[0-9]+\\.[0-9]+") || !target.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) return false;
        String[] from = source.split("\\."), to = target.split("\\.");
        return from[0].equals(to[0]) && from[1].equals(to[1]) && patch(target).compareTo(patch(source)) >= 0;
    }

    private static java.math.BigInteger patch(String version) {
        return new java.math.BigInteger(version.substring(version.lastIndexOf('.') + 1));
    }

    /** Topology-only inspection retains clarification when configuration evidence is unavailable. */
    public static List<MappingChoice> mappingChoices(String moduleJson, String pack) throws StudioBuildException {
        return mappingChoices(moduleJson, "", pack);
    }

    /** Only a configuration ID linked to exactly one pack-declared configuration class resolves a shared runtime class. */
    public static List<MappingChoice> mappingChoices(String moduleJson, String configurationJson, String pack)
            throws StudioBuildException {
        try {
            JsonNode root = read(moduleJson);
            Map<String, JsonNode> configs = configurationJson == null || configurationJson.isBlank()
                    ? Map.of() : configurations(read(configurationJson));
            List<MappingChoice> choices = new ArrayList<>();
            Set<ComponentRef> seen = new HashSet<>();
            for (JsonNode flow : root.path("flows")) {
                List<JsonNode> elements = new ArrayList<>();
                elements.add(flow.path("consumer"));
                flow.path("flowElements").forEach(elements::add);
                for (JsonNode element : elements) {
                    ComponentRef ref = new ComponentRef(required(flow, "name"), required(element, "componentName"));
                    if (!seen.add(ref)) continue;
                    var candidates = exactCandidates(element, pack);
                    if (candidates.size() > 1 && inferredVariant(element, configs, candidates) == null) choices.add(new MappingChoice(ref, candidates.stream().map(ComponentMeta::getName).sorted().toList()));
                }
            }
            return List.copyOf(choices);
        } catch (StudioBuildException e) { throw e; }
        catch (Exception e) { throw new StudioBuildException("Cannot inspect Ikasan module metadata JSON.", e); }
    }

    public static Result convert(String moduleJson, String configurationJson, String pack, String packageName)
            throws StudioBuildException {
        return convert(moduleJson, configurationJson, pack, packageName, Map.of());
    }

    /**
     * Imports a module metadata object and an optional configuration object/array. The caller supplies
     * the design-time package and meta-pack because runtime exports do not reliably identify them.
     * Unsupported or ambiguous components and graphs fail before any project files are changed.
     */
    public static Result convert(String moduleJson, String configurationJson, String pack, String packageName,
                                 Map<ComponentRef, String> componentMappings) throws StudioBuildException {
        try {
            JsonNode raw = read(moduleJson);
            if (!(raw instanceof ObjectNode topology) || !topology.path("flows").isArray())
                throw problem("Expected an Ikasan module metadata object with a flows array.");
            if (topology.has("applicationPackageName"))
                throw problem("This is a Studio model. Use the Studio model import option.");
            if (packageName == null || !javax.lang.model.SourceVersion.isName(packageName))
                throw problem("Supply a valid application Java package.");
            var manifest = ComponentLibrary.getMetaPackManifest(pack);
            String runtimeVersion = topology.path("ikasanVersion").asText("");
            if (!runtimeVersion.isBlank() && !runtimeVersion.equals(manifest.ikasanVersion())
                    && !forwardPatch(runtimeVersion, manifest.ikasanVersion()))
                throw problem("The export uses Ikasan " + runtimeVersion + "; select its matching meta-pack or a newer patch in the same major/minor line. Downgrades and cross-minor/major imports require a separate migration.");
            JsonNode configuration = configurationJson == null || configurationJson.isBlank()
                    ? JSON.createArrayNode() : read(configurationJson);
            Map<String, JsonNode> configurations = configurations(configuration);
            List<String> review = new ArrayList<>();
            review.add("Runtime JSON does not include Java implementations, dependencies, Spring wiring or all builder settings. Review these before building or running.");
            review.add("Compare the generated Maven POM with the original project: restore any custom dependencies, repositories, plugins and build profiles needed by your application.");
            if (!runtimeVersion.isBlank() && !runtimeVersion.equals(manifest.ikasanVersion()))
                review.add("Patch upgrade: export Ikasan " + runtimeVersion + " imported using " + pack
                        + " (Ikasan " + manifest.ikasanVersion() + "). Generated dependencies target the newer patch."
                        + " Review API/configuration differences and compile and test before starting flows; compatibility is not guaranteed.");
            if (runtimeVersion.isBlank()) review.add("The export has no ikasanVersion; verify the selected meta-pack against the original application.");
            Module base = new Module(pack);
            base.setName(required(topology, "name"));
            base.setApplicationPackageName(packageName);
            base.defaultUnsetMandatoryProperties();
            JsonNode port = topology.get("port");
            if (port != null && !port.isNull()) {
                String supplied = port.asText();
                if (!(port.isIntegralNumber() || port.isTextual()) || !supplied.matches("[0-9]{1,5}")
                        || Integer.parseInt(supplied) < 1 || Integer.parseInt(supplied) > 65535)
                    throw problem("The module metadata port must be an integer from 1 to 65535. Correct the export before importing.");
                base.setPort(Integer.toString(Integer.parseInt(supplied)));
            } else {
                review.add("Application HTTP port was not supplied in the module metadata. Verify Studio's default port "
                        + base.getPort() + " against the original application before running.");
            }
            ObjectNode design = (ObjectNode) JSON.readTree(ComponentIO.toJson(base));
            // Runtime metadata supplies per-flow startup controls, not a module-wide default.
            // All imported flows receive an explicit setting below.
            design.put("flowStartupType", "MANUAL");
            if (topology.hasNonNull("description")) design.set("description", topology.get("description"));
            // Runtime module 'version' is the application's version, not Studio's meta-pack ID.
            ObjectNode source = design.putObject(SOURCE_FIELD);
            source.set("module", topology.deepCopy());
            source.set("configuration", configuration.deepCopy());
            ArrayNode flows = design.putArray("flows");
            if (topology.path("flows").size() > 1_000) throw problem("Import at most 1,000 flows in one module.");
            Set<String> names = new HashSet<>();
            Set<String> usedConfigurations = new HashSet<>();
            for (JsonNode flow : topology.path("flows")) {
                String name = required(flow, "name");
                if (!names.add(name)) throw problem("Duplicate flow name: " + name);
                flows.add(flow(flow, pack, configurations, usedConfigurations, review, componentMappings));
            }
            for (String id : configurations.keySet()) if (!usedConfigurations.contains(id))
                review.add("Configuration " + id + ": retained only; no supported component mapping applied (module, flow, invoker or unmatched resource).");
            source.set("review", JSON.valueToTree(review));
            String result = JSON.writerWithDefaultPrettyPrinter().writeValueAsString(design);
            Module validated = ComponentIO.validatePersistedModuleJson(result, "Ikasan runtime import", false);
            // Prove that Studio's tree representation has not lost or rewired runtime transitions.
            JsonNode roundTrip = JSON.readTree(ComponentIO.toValidatedModuleJson(validated));
            for (int i = 0; i < flows.size(); i++) {
                if (!edges(flows.get(i)).equals(edges(roundTrip.path("flows").get(i))))
                    throw problem("Flow " + flows.get(i).path("name").asText() + ": graph cannot be represented without changing transitions.");
            }
            return new Result(result, review);
        } catch (StudioBuildException e) {
            throw e;
        } catch (Exception e) {
            // Do not expose JSON excerpts or configuration values through parser exception text.
            throw new StudioBuildException("Cannot import Ikasan JSON. Check the document structure and selected meta-pack. No files were changed.", e);
        }
    }

    private static ObjectNode flow(JsonNode input, String pack, Map<String, JsonNode> configs,
                                   Set<String> used, List<String> review, Map<ComponentRef, String> mappings) throws Exception {
        String flowName = required(input, "name");
        if (!input.path("consumer").isObject() || !input.path("flowElements").isArray()
                || !input.path("transitions").isArray()) throw problem("Flow " + flowName + ": consumer, flowElements and transitions are required.");
        LinkedHashMap<String, JsonNode> components = new LinkedHashMap<>();
        String consumer = required(input.get("consumer"), "componentName");
        components.put(consumer, input.get("consumer"));
        for (JsonNode element : input.path("flowElements")) {
            String name = required(element, "componentName");
            if (name.equals(consumer) && element.equals(input.get("consumer"))) continue;
            if (components.putIfAbsent(name, element) != null) throw problem("Flow " + flowName + ": duplicate component " + name);
        }
        if (components.size() > 500) throw problem("Flow " + flowName + ": import at most 500 components per flow.");
        Map<String, List<JsonNode>> outgoing = new LinkedHashMap<>();
        Map<String, Integer> incoming = new HashMap<>();
        Set<String> edgeKeys = new HashSet<>();
        for (JsonNode edge : input.path("transitions")) {
            String from = required(edge, "from"), to = required(edge, "to"), label = required(edge, "name");
            if (!components.containsKey(from) || !components.containsKey(to)) throw problem("Flow " + flowName + ": transition refers to a missing component.");
            if (!edgeKeys.add(from + "\u0000" + label) || incoming.merge(to, 1, Integer::sum) > 1 || to.equals(consumer))
                throw problem("Flow " + flowName + ": duplicate routes, joins or cycles require an explicit Studio mapping.");
            outgoing.computeIfAbsent(from, ignored -> new ArrayList<>()).add(edge);
        }
        Set<String> reached = new HashSet<>();
        Deque<String> pending = new ArrayDeque<>();
        pending.add(consumer);
        while (!pending.isEmpty()) {
            String node = pending.removeFirst();
            if (!reached.add(node)) throw problem("Flow " + flowName + ": cyclic topology is unsupported.");
            for (JsonNode edge : outgoing.getOrDefault(node, List.of())) pending.add(required(edge, "to"));
        }
        if (reached.size() != components.size()) throw problem("Flow " + flowName + ": disconnected components are not imported silently.");
        JsonNode declaredStartup = input.get("flowStartupType");
        String startup;
        if (declaredStartup == null || declaredStartup.isNull()) {
            startup = "MANUAL";
            review.add("Flow '" + flowName + "': startup type was not supplied. Imported as MANUAL; verify the original startup setting before running.");
        } else if (declaredStartup.isTextual()
                && Set.of("AUTOMATIC", "MANUAL", "DISABLED").contains(declaredStartup.textValue())) {
            startup = declaredStartup.textValue();
        } else {
            throw problem("Flow '" + flowName + "': unrecognised startup type. Expected AUTOMATIC, MANUAL or DISABLED; correct the export before importing.");
        }
        ObjectNode result = JSON.createObjectNode().put("name", flowName).put("flowStartupType", startup);
        if (input.hasNonNull("configurationId")) result.set("configurationId", input.get("configurationId"));
        result.set("transitions", input.get("transitions").deepCopy());
        ArrayNode elements = result.putArray("flowElements");
        for (var entry : components.entrySet()) {
            JsonNode raw = entry.getValue();
            ComponentRef ref = new ComponentRef(flowName, entry.getKey());
            ComponentMeta meta = resolve(raw, pack, mappings.get(ref), configs);
            if (!mappings.containsKey(ref) && exactCandidates(raw, pack).size() > 1)
                review.add(flowName + " → " + entry.getKey() + ": inferred variant " + meta.getName()
                        + " from its linked configuration class " + configurationClass(meta)
                        + ". Review the original message-provider wiring before running.");
            if (entry.getKey().equals(consumer) != meta.isConsumer()) throw problem("Flow " + flowName + ": invalid consumer placement.");
            List<JsonNode> routes = outgoing.getOrDefault(entry.getKey(), List.of());
            if (routes.size() > 1 && !meta.isRouter()) throw problem("Flow " + flowName + ": branching component is not a supported router.");
            ObjectNode target = JSON.createObjectNode();
            target.put("componentName", entry.getKey());
            target.put("componentType", meta.getComponentType());
            target.put("implementingClass", meta.getImplementingClass());
            if (meta.getAdditionalKey() != null) target.put("additionalKey", meta.getAdditionalKey());
            for (String key : List.of("description", "configurationId"))
                if (raw.hasNonNull(key)) target.set(key, raw.get(key));
            if (meta.isGeneratesUserImplementedClass()) {
                target.put("userImplementedClassName", required(raw, "implementingClass"));
                if (!meta.getAllowableProperties().containsKey("requiresStub"))
                    throw problem("Component " + entry.getKey() + ": the pack cannot preserve this existing implementation without generating a replacement.");
                target.put("requiresStub", false);
                for (String typeProperty : List.of("fromType", "toType")) {
                    if (meta.getAllowableProperties().containsKey(typeProperty)) target.put(typeProperty, "java.lang.Object");
                }
                review.add(flowName + " → " + entry.getKey() + ": supply existing implementation " + required(raw, "implementingClass") + " and its Spring bean/wiring.");
            }
            if (meta.isRouter()) {
                if (routes.stream().anyMatch(e -> e.path("name").asText().contains(",")))
                    throw problem("Flow " + flowName + ": route names containing commas cannot be represented by this pack.");
                target.put("routeNames", String.join(",", routes.stream().map(e -> e.path("name").asText()).toList()));
            }
            if (raw.path("decorators").isArray() && !raw.path("decorators").isEmpty())
                review.add(flowName + " → " + entry.getKey() + ": decorators retained in original metadata; configure equivalent Studio decorators manually.");
            String id = raw.path("configurationId").asText("");
            if (!id.isBlank()) {
                JsonNode config = configs.get(id);
                if (config == null) review.add(flowName + " → " + entry.getKey() + ": no configuration supplied for " + id + ".");
                else {
                    used.add(id);
                    applyConfiguration(target, config, meta, flowName, review);
                }
            }
            String inputTypeProperty = meta.getExpectedInputTypeProperty();
            var inputType = inputTypeProperty == null ? null : meta.getAllowableProperties().get(inputTypeProperty);
            if (inputType != null && inputType.isMandatory() && !target.hasNonNull(inputTypeProperty))
                review.add(flowName + " → " + entry.getKey() + ": supply " + inputTypeProperty
                        + " (the input Java class); runtime metadata does not include this builder setting.");
            if (entry.getKey().equals(consumer)) result.set("consumer", target); else elements.add(target);
        }
        return result;
    }

    private static List<ComponentMeta> exactCandidates(JsonNode raw, String pack) throws StudioBuildException {
        String type = required(raw, "componentType"), implementation = required(raw, "implementingClass");
        return ComponentLibrary.getPaletteComponentList(pack).stream()
                .filter(m -> type.equals(m.getComponentType()) && implementation.equals(m.getImplementingClass())).toList();
    }

    private static ComponentMeta resolve(JsonNode raw, String pack, String selectedVariant,
                                         Map<String, JsonNode> configs) throws StudioBuildException {
        String type = required(raw, "componentType"), implementation = required(raw, "implementingClass");
        if (!javax.lang.model.SourceVersion.isName(implementation))
            throw problem("Component " + required(raw, "componentName") + ": implementingClass must be a Java class name.");
        var candidates = exactCandidates(raw, pack);
        if (selectedVariant != null) {
            return candidates.stream().filter(m -> selectedVariant.equals(m.getName())).findFirst()
                    .orElseThrow(() -> problem("Selected variant does not match runtime component " + raw.path("componentName").asText()));
        }
        if (candidates.size() == 1) return candidates.get(0);
        if (candidates.size() > 1) {
            ComponentMeta inferred = inferredVariant(raw, configs, candidates);
            if (inferred != null) return inferred;
        }
        if (candidates.size() > 1) throw problem("Component " + required(raw, "componentName") + ": select a variant explicitly: "
                + String.join(", ", candidates.stream().map(ComponentMeta::getName).toList())
                + ". Runtime JSON does not identify all message-provider wiring.");
        candidates = ComponentLibrary.getPaletteComponentList(pack).stream().filter(m -> type.equals(m.getComponentType())
                && m.isGeneratesUserImplementedClass() && (m.isGeneric() || m.getAdditionalKey() == null)).toList();
        if (candidates.size() > 1) {
            var genericContracts = candidates.stream().filter(m -> m.isGeneric()
                    || (type + ".Custom").equals(m.getImplementingClass())).toList();
            if (genericContracts.size() == 1) return genericContracts.get(0);
        }
        if (candidates.size() != 1) throw problem("Component " + required(raw, "componentName") + ": no unambiguous mapping for " + implementation + " in " + pack + ".");
        return candidates.get(0);
    }

    private static String configurationClass(ComponentMeta meta) {
        String declared = meta.getRuntimeConfigurationClass();
        var property = meta.getAllowableProperties().get("configuration");
        return declared != null ? declared : property == null ? null : property.getUsageDataType();
    }

    private static ComponentMeta inferredVariant(JsonNode raw, Map<String, JsonNode> configs,
                                                  List<ComponentMeta> candidates) {
        JsonNode config = configs.get(raw.path("configurationId").asText(""));
        if (config == null) return null;
        String type = config.path("implementingClass").asText("");
        if (type.isBlank()) return null;
        var matches = candidates.stream().filter(candidate -> type.equals(configurationClass(candidate))).toList();
        // No guessing from names, cron expressions, parameter values, nearby records or Java class inheritance.
        return matches.size() == 1 ? matches.get(0) : null;
    }

    private static void applyConfiguration(ObjectNode target, JsonNode config, ComponentMeta meta,
                                           String flowName, List<String> review) throws StudioBuildException {
        String configurationClass = configurationClass(meta);
        boolean matchingClass = config.path("implementingClass").asText().equals(configurationClass);
        List<String> unapplied = new ArrayList<>();
        for (JsonNode parameter : config.path("parameters")) {
            String name = required(parameter, "name");
            String studioProperty = meta.runtimeConfigurationProperty(name);
            var property = studioProperty == null ? null : meta.getAllowableProperties().get(studioProperty);
            JsonNode value = parameter.get("value");
            // Unset REST parameters are provenance, not work for the developer to resolve.
            if (value == null || value.isNull()) continue;
            if (matchingClass && studioProperty != null && property != null
                    && compatible(value, property.getPropertyDataType())) {
                target.set(studioProperty, value.deepCopy());
            } else if (!matchingClass || !value.equals(meta.getRuntimeConfigurationDefaults().get(name))) {
                // Match typed JSON against a default verified for this exact pack/component construction.
                // Unknown fields, changed defaults and mismatched configuration classes still need review.
                unapplied.add(name);
            }
        }
        if (!unapplied.isEmpty()) review.add(flowName + " → " + target.path("componentName").asText()
                + ": review configuration fields not applied: " + String.join(", ", unapplied)
                + ". Compare with the original configuration before running.");
    }

    private static boolean compatible(JsonNode value, Class<?> type) {
        if (org.ikasan.studio.core.model.StringCollectionValues.supports(type))
            return org.ikasan.studio.core.model.StringCollectionValues.compatible(type, value);
        if (type == String.class) return value.isTextual();
        if (type == Boolean.class || type == boolean.class) return value.isBoolean();
        if (type == Integer.class || type == int.class) return value.isIntegralNumber() && value.canConvertToInt();
        if (type == Long.class || type == long.class) return value.isIntegralNumber() && value.canConvertToLong();
        return false;
    }

    private static Map<String, JsonNode> configurations(JsonNode json) throws StudioBuildException {
        Map<String, JsonNode> result = new LinkedHashMap<>();
        Iterable<JsonNode> entries = json.isArray() ? json : List.of(json);
        for (JsonNode entry : entries) {
            String id = required(entry, "configurationId");
            if (!entry.path("parameters").isArray()) throw problem("Configuration " + id + ": parameters must be an array.");
            Set<String> names = new HashSet<>();
            for (JsonNode parameter : entry.get("parameters")) {
                if (!names.add(required(parameter, "name")))
                    throw problem("Configuration " + id + ": duplicate parameter.");
                // Ikasan REST uses NON_NULL serialization: an absent value is an unset parameter.
                // Keep the original record unchanged; applyConfiguration never applies absent/null values.
            }
            if (result.putIfAbsent(id, entry) != null) throw problem("Duplicate configurationId: " + id);
        }
        return result;
    }

    private static Set<JsonNode> edges(JsonNode flow) {
        Set<JsonNode> result = new HashSet<>();
        for (JsonNode edge : flow.path("transitions")) result.add(edge);
        return result;
    }

    private static JsonNode read(String input) throws Exception {
        if (input == null || input.length() > MAX_JSON_LENGTH) throw problem("Each import document must be at most 8 MiB of text.");
        if (input.startsWith("\uFEFF")) input = input.substring(1);
        try (JsonParser parser = JSON.createParser(input)) {
            JsonNode value = JSON.readTree(parser);
            if (value == null || parser.nextToken() != null) throw problem("Supply one JSON document per input.");
            return value;
        }
    }

    private static String required(JsonNode node, String field) throws StudioBuildException {
        if (node == null || !node.path(field).isTextual() || node.path(field).asText().isBlank())
            throw problem("Missing or invalid text field: " + field);
        return node.path(field).asText();
    }

    private static StudioBuildException problem(String message) { return new StudioBuildException(message); }
}
