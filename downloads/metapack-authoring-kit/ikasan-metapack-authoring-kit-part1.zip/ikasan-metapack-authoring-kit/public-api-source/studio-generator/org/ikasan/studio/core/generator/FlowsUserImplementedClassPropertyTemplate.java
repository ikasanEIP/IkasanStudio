package org.ikasan.studio.core.generator;

import org.ikasan.studio.core.model.ikasan.instance.ComponentProperty;
import org.ikasan.studio.core.metapack.model.ComponentPropertyMeta;

import java.util.Map;

public class FlowsUserImplementedClassPropertyTemplate extends Generator {

    public static String create(String metapackVersion, ComponentProperty property, String newPackageName, String clazzName, String prefix) throws StudioGeneratorException {
        return generateContents(metapackVersion, newPackageName, clazzName, property, prefix);
    }

    protected static String generateContents(String metapackVersion, String packageName, String clazzName, ComponentProperty property, String prefix) throws StudioGeneratorException {
        String interfaceName = property.getMeta().getUsageDataType();
        String templateName;
        if (property.getMeta().getUserImplementClassFtlTemplate() != null
                && !property.getMeta().getUserImplementClassFtlTemplate().isBlank()) {
            templateName = property.getMeta().getUserImplementClassFtlTemplate();
        } else if (ComponentPropertyMeta.CONFIGURATION.equals(property.getMeta().getPropertyName())) {
            templateName = "configurationTemplate_en.ftl";
        } else {
            templateName = "genericInterfaceTemplate_en.ftl";
        }
        Map<String, Object> configs = getBasicTemplateConfigs();
        configs.put(STUDIO_PACKAGE_TAG, packageName);
        configs.put(CLASS_NAME_TAG, clazzName);
        configs.put(INTERFACE_NAME_TAG, interfaceName);
        configs.put(PREFIX_TAG, prefix);
        return FreemarkerUtils.generateFromTemplate(metapackVersion, templateName, configs);
    }
}