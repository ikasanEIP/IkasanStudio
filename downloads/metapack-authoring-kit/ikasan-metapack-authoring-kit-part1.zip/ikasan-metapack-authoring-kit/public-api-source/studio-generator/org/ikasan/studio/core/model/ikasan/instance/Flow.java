package org.ikasan.studio.core.model.ikasan.instance;

import org.ikasan.studio.core.diagnostics.StudioDiagnosticEvent;

import org.ikasan.studio.core.model.command.FlowElementRemoval;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.ikasan.studio.core.StudioBuildException;
import org.ikasan.studio.core.metapack.model.ComponentMeta;
import org.ikasan.studio.core.metapack.ComponentLibrary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class Flow extends BasicElement {
    private static final Logger LOG = LoggerFactory.getLogger(BasicElement.class);
    // The fields of a Flow will need to be known for serialisation
    public static final String CONSUMER_JSON_TAG = "consumer";
    public static final String TRANSITIONS_JSON_TAG = "transitions";
    public static final String FLOW_ELEMENTS_JSON_TAG = "flowElements";
    public static final String EXCEPTION_RESOLVER_JSON_TAG = "exceptionResolver";

    private FlowElement consumer;
    private FlowRoute flowRoute;
    private ExceptionResolver exceptionResolver;

    /**
     * Used primarily during deserialization.
     */
    public Flow() throws StudioBuildException {
        super (ComponentLibrary.getFLowComponentMeta(ComponentLibrary.DEFAULT_IKASAN_PACK), null);
        LOG.warn("STUDIO: Parameterless version of flow called");
    }

    public Flow(String metapackVersion) throws StudioBuildException {
        super (ComponentLibrary.getFLowComponentMeta(metapackVersion), null);
        flowRoute = FlowRoute.flowRouteBuilder().flow(this).build();
    }

    // The Builders are used to create test fixtures and occasionally, partially constructed Flows
    // Only the core properties are set in the constructor in order to allow loose coupling between the
    // IDE integration and the underlying version of Ikasan
    @Builder(builderMethodName = "flowBuilder")
    public Flow(
                @NonNull
                String metapackVersion,
                FlowElement consumer,
                FlowRoute flowRoute,
                ExceptionResolver exceptionResolver,
                String name,
                String description) throws StudioBuildException {
        super(ComponentLibrary.getFLowComponentMeta(metapackVersion), null);
        if (consumer != null) {
            if (!consumer.getComponentMeta().isConsumer()) {
                LOG.warn(StudioDiagnosticEvent.format(StudioDiagnosticEvent.Event.CONFIGURATION_INVALID, null, null, getIdentity(), null));
            } else {
                this.consumer = consumer;
            }
        }
        if (flowRoute != null) {
            this.flowRoute = flowRoute;
        } else {
            this.flowRoute = FlowRoute.flowRouteBuilder().flow(this).build();
        }
        this.exceptionResolver = exceptionResolver;
        super.setName(name);
        super.setDescription(description);
    }

    /**
     * @param ikasanFlowComponentToBeRemoved from this flow
     * @return a record of what was removed and from where, so the removal can be reversed (e.g. to support
     * IDE Undo); null if there was nothing to remove.
     */
    public FlowElementRemoval removeFlowElement(FlowElement ikasanFlowComponentToBeRemoved) {
        if (ikasanFlowComponentToBeRemoved != null) {
            if (ikasanFlowComponentToBeRemoved.getComponentMeta().isConsumer()) {
                setConsumer(null);
                return new FlowElementRemoval(ikasanFlowComponentToBeRemoved, this, null, -1, true, false, List.of());
            } else if (ikasanFlowComponentToBeRemoved.getComponentMeta().isExceptionResolver()) {
                setExceptionResolver(null);
                return new FlowElementRemoval(ikasanFlowComponentToBeRemoved, this, null, -1, false, true, List.of());
            } else if (flowRoute != null) {
                return ikasanFlowComponentToBeRemoved.getContainingFlowRoute().removeFlowElement(ikasanFlowComponentToBeRemoved);
            } else {
                LOG.warn("STUDIO: Attempt to remove element " + ikasanFlowComponentToBeRemoved + " because it could not be found in the memory model");
            }
        }
        return null;
    }

    public boolean hasConsumer() {
        return getConsumer() != null;
    }

    public boolean hasAnyComponents() {
        return
                hasExceptionResolver() || hasConsumer() || hasFlowComponents();
    }

    public boolean hasFlowComponents() {
        return ! flowRoute.isEmpty() || flowRoute.isEmpty();
    }

    /**
     * Does the Flow have a valid exception resolver
     * @return if the flow has a valid exception resolver.
     */
    public boolean hasExceptionResolver() {
        return (exceptionResolver != null);
    }

    public boolean anyFlowRouteHasComponents(FlowRoute flowRoute) {
        if (flowRoute != null) {
            if (flowRoute.getFlowElements() != null && !flowRoute.getFlowElements().isEmpty()) {
                return true;
            }
        }
        if (flowRoute != null && flowRoute.getChildRoutes() != null) {
            for(FlowRoute childRoute : flowRoute.getChildRoutes()) {
                if (anyFlowRouteHasComponents(childRoute)) {
                    return true;
                }
            }
        }
        return false;
    }

    public FlowRoute getFlowRouteContaining(FlowRoute searchRoute, FlowElement targetFlowElement) {
        if (searchRoute != null) {
            if (searchRoute.getFlowElements() != null && !searchRoute.getFlowElements().isEmpty() && searchRoute.getFlowElements().contains(targetFlowElement)) {
                return searchRoute;
            }
        }
        if (searchRoute != null && searchRoute.getChildRoutes() != null) {
            for(FlowRoute childRoute : searchRoute.getChildRoutes()) {
                if (getFlowRouteContaining(childRoute, targetFlowElement) != null) {
                    return childRoute;
                }
            }
        }
        return null;
    }

    /**
     * Walks backwards from flowElement to the nearest upstream element whose declared type represents the
     * actual payload flowing into flowElement (see {@link #skipNonPayloadBearingElements} for which component
     * types get walked past). Used for a best-effort design-time check (see
     * FlowElement#getUpstreamTypeMismatchWarning) - not a substitute for real type resolution.
     * @param flowElement to find the payload-bearing predecessor of
     * @return the nearest payload-bearing upstream FlowElement, the flow's Consumer, or null if there is
     * nothing upstream to inspect (flowElement's containing route is not wired into this flow at all)
     */
    public FlowElement findPayloadSourceElement(FlowElement flowElement) {
        return skipNonPayloadBearingElements(findImmediatePredecessor(flowElement));
    }

    /**
     * Starting from candidate (typically an immediate upstream neighbour, however that was determined), walks
     * further back past untyped Routers and Filters, and Debug breakpoints (which always pass the
     * original message through unchanged - see DebugTransitionComponent#filter), and internal route anchors
     * (diagram structure, not payload-producing components) - to the nearest element whose
     * declared type really is what flows into whatever candidate feeds. Also usable directly against a
     * not-yet-inserted candidate (e.g. resolved from drop coordinates before a new component has a position of
     * its own - see DesignerCanvas#applySuggestedInputTypeFromUpstream), unlike {@link #findPayloadSourceElement}
     * which requires flowElement to already have a containingFlowRoute.
     * @param candidate the starting point to walk back from (may itself be a Router/Filter/Debug, or null)
     * Typed routers and filters provide a downstream contract even though they do not transform accepted payloads.
     * Their own upstream mismatch is checked separately. Debug components remain transparent.
     * @return the nearest element with a payload type, including a typed router or filter, or null
     */
    public FlowElement skipNonPayloadBearingElements(FlowElement candidate) {
        FlowElement predecessor = candidate;
        while (predecessor != null && predecessor.getComponentMeta() != null
                && (((predecessor.getComponentMeta().isRouter() || predecessor.getComponentMeta().isFilter())
                        && !hasConcretePayloadOutput(predecessor))
                    || predecessor.getComponentMeta().isDebug()
                    || predecessor.getComponentMeta().isInternalEndpoint())) {
            predecessor = findImmediatePredecessor(predecessor);
        }
        return predecessor;
    }

    private static boolean hasConcretePayloadOutput(FlowElement element) {
        String output = element.getEffectiveOutputTypeDescription();
        return !PayloadTypes.unknown(output);
    }

    /**
     * The element immediately before flowElement in model order: its previous sibling in the same FlowRoute,
     * or - if flowElement is the first thing in its route - the router owning that route (when the route is
     * a branch) or the flow's Consumer (when the route is the flow's own top-level route).
     */
    private FlowElement findImmediatePredecessor(FlowElement flowElement) {
        FlowRoute route = flowElement.getContainingFlowRoute();
        if (route == null || route.getFlowElements() == null) {
            return null;
        }
        int index = route.getFlowElements().indexOf(flowElement);
        if (index > 0) {
            return route.getFlowElements().get(index - 1);
        }
        FlowElement owningRouter = findOwningRouter(getFlowRoute(), route);
        return owningRouter != null ? owningRouter : getConsumer();
    }

    /**
     * Finds the router whose branch targetChildRoute is, by searching the route tree for whichever route lists
     * targetChildRoute among its own childRoutes - that route's own last element is, by construction, the router
     * that owns the branch (see the "MRR is always the last element" convention used throughout the ftl templates).
     */
    private FlowElement findOwningRouter(FlowRoute searchRoute, FlowRoute targetChildRoute) {
        if (searchRoute == null || searchRoute.getChildRoutes() == null) {
            return null;
        }
        if (searchRoute.getChildRoutes().contains(targetChildRoute)) {
            List<FlowElement> elements = searchRoute.getFlowElements();
            return (elements != null && !elements.isEmpty()) ? elements.get(elements.size() - 1) : null;
        }
        for (FlowRoute childRoute : searchRoute.getChildRoutes()) {
            FlowElement found = findOwningRouter(childRoute, targetChildRoute);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    /**
     * This method is used by FreeMarker, the IDE may incorrectly identify it as unused.
     * @return A list of all non-null flow elements, including the consumer
     */
    @SuppressWarnings("unused")
    public List<FlowElement> ftlGetConsumerAndFlowElements() {

        List<FlowElement> allElements = new ArrayList<>();
        // Only the default (primary) flowRoute includes the consumer
        if (getConsumer() != null) {
            allElements.add(getConsumer());
        }
        getAllFlowElementsInAnyRoute(allElements, getFlowRoute());
        return allElements;
    }

    private void getAllFlowElementsInAnyRoute(List<FlowElement> flowElementsList, FlowRoute flowRoute) {
        if (flowRoute != null) {
            List<FlowElement> thisRouteFlowElementList = flowRoute.getFlowElements();
            if (thisRouteFlowElementList != null && !thisRouteFlowElementList.isEmpty()) {
                flowElementsList.addAll(thisRouteFlowElementList);
            }
        }
        if (flowRoute != null && flowRoute.getChildRoutes() != null) {
            for(FlowRoute childRoute : flowRoute.getChildRoutes()) {
                getAllFlowElementsInAnyRoute(flowElementsList, childRoute);
            }
        }
    }

    /**
     * This method is used by FreeMarker, the IDE may incorrectly identify it as unused.
     * @return A list of all non-null flow elements, including the consumer, excluding any endpoints
     */
    @SuppressWarnings("unused")
    public List<FlowElement> ftlGetAllFlowElementsInAnyRouteNoEndpoints() {

        List<FlowElement> allElements = ftlGetConsumerAndFlowElements();
        allElements = allElements.stream()
            .filter(flowElement -> !flowElement.componentMeta.isEndpoint())
            .toList();
        return allElements;
    }

    /**
     * This method is used by FreeMarker, the IDE may incorrectly identify it as unused.
     * @return A list of all non-null flow elements, including the consumer, excluding any endpoints
     */
    @SuppressWarnings("unused")
    public List<FlowElement> getFlowElementsNoExternalEndPoints() {

        List<FlowElement> allElements = ftlGetConsumerAndFlowElements();
        allElements = allElements.stream()
            .filter(x-> ! x.componentMeta.isEndpoint() || x.componentMeta.isInternalEndpoint())
            .toList();
        return allElements;
    }

    /**
     * Determine the current state of the flow for completeness
     * @return A status string
     */
    @JsonIgnore
    public String getFlowIntegrityStatus() {
        String status = "";
        if (! hasConsumer()) {
            status += "The flow needs a consumer";
        }
        if (flowRoute != null) {
            status += flowRoute.getFlowIntegrityStatus();
        }
        if (!status.isEmpty()) {
            status += " to be complete.";
        }
        return status;
    }

    /**
     * If the component can be added to the flow, return an empty string otherwise state the reason why
     * @param newComponent to be added
     * @return reason why the component can not be added or empty string if there is no problem.
     */
    public String issueCausedByAdding(ComponentMeta newComponent, FlowRoute targetRoute) {
        String reason = "";
        if (newComponent.isFlow()) {
            reason += "You can add a flow to a module but not inside another flow. ";
        } else if (getConsumer() != null && newComponent.isConsumer()) {
            reason += "The flow cannot have more then one consumer. ";
        } else if (getExceptionResolver() != null && newComponent.isExceptionResolver()) {
            reason += "The flow cannot have more then one exception resolver. ";
        } else if (targetRoute == null && flowRoute != null && !flowRoute.isEmpty()) {
            reason += "Please drop into route. ";
        }
        return reason;
    }

    /**
     * The intent is to clone the existing flow but to a different meta-pack metapackVersion.
     * @param metapackVersion for cloned flow
     * @return the cloned module with the new meta pack version
     * @throws StudioBuildException when cloning is not possible.
     */
    public Flow cloneToVersion(String metapackVersion) throws StudioBuildException {
        if (metapackVersion == null || metapackVersion.isBlank()) {
            LOG.warn(StudioDiagnosticEvent.format(StudioDiagnosticEvent.Event.CONFIGURATION_INVALID, null, null, null, null));
            return null;
        }
        Flow clonedFlow = new Flow(metapackVersion);

        if (this.flowRoute != null) {
            clonedFlow.setFlowRoute(this.flowRoute.cloneToVersion(metapackVersion, clonedFlow));
        } else {
            clonedFlow.setFlowRoute(FlowRoute.flowRouteBuilder().flow(clonedFlow).build());
        }
        if (this.getConsumer() != null) {
            clonedFlow.setConsumer(this.getConsumer().cloneToVersion(metapackVersion, clonedFlow, clonedFlow.getFlowRoute()));
        }
        if (this.getExceptionResolver() != null) {
            clonedFlow.setExceptionResolver(this.getExceptionResolver().cloneToVersion(metapackVersion, clonedFlow));
        }
        return clonedFlow;
    }

    @Override
    public String toSimpleString() {

        return getIdentity() + "[" + super.toSimpleString() +
                " consumer=" + (consumer!=null ? consumer.toSimpleString() : null) + "\n" +
                ", exceptionResolver=" + (exceptionResolver!=null ? exceptionResolver.toSimpleString() : null) + "\n" +
                ", flowRoute [" + (flowRoute!=null ? flowRoute.toSimpleString() : null) + "]" + "\n" +
                ']';
    }
}
