package ${studioPackageTag};

/**
* Filtering rule (algorithm) for org.ikasan.filter.DefaultMessageFilter, which wraps an instance of this class
* and delegates each payload to it - accept() decides whether the payload continues through the flow (true)
* or is discarded (false); unlike a plain Filter implementation there's no need to hand back the payload here,
* since DefaultMessageFilter itself returns the original object unchanged whenever accept() returns true.
*
* Note: accept() below always receives just the payload, never the full FlowEvent - unlike Broker/Converter,
* there is no full-event mode to opt into here. If your filter logic needs the event's identifier, timestamp
* or other metadata, a Broker (with its input type set to org.ikasan.spec.flow.FlowEvent) is a better fit.
*
* Do not mutate the payload inside accept() below. Nothing in the flow defends against it - the exact same
* object reference you're given is what DefaultMessageFilter passes on to the next component when you return
* true - but a filter rule is meant to be a pass/fail gate, not a place to transform the payload's content or
* type. Use a Converter or Translator for that instead.
*
* @author Ikasan Development Team
*
*/

@org.springframework.stereotype.Component("${studioPackageTag}.${flowElement.getPropertyValue("userImplementedClassName")}")

public class ${flowElement.getPropertyValue("userImplementedClassName")} implements org.ikasan.spec.component.filter.FilterRule<${flowElement.getPropertyValue("fromType")}><#if flowElement.getPropertyValue("configuredResource")?has_content && flowElement.getPropertyValue("configuredResource")>,org.ikasan.spec.configuration.ConfiguredResource<${flowElement.getPropertyValue("configuration")}><#elseif flowElement.getPropertyValue("configuration")?has_content>, org.ikasan.spec.configuration.Configured<${flowElement.getPropertyValue("configuration")}></#if>
{
<#if flowElement.getPropertyValue("configuration")??>
${flowElement.getPropertyValue("configuration")} configuration;
</#if>
<#if flowElement.getPropertyValue("configuredResource")?has_content && flowElement.getPropertyValue("configuredResource")>
String configurationId;
</#if>
/**
* Evaluate the payload against this rule.
*
* @param payload - the incoming payload
* @return true if the payload is accepted (passed through, unmodified) - false to stop processing it here;
* there is no separate "discarded" destination it gets routed to, flow processing for this event simply ends.
* @throws org.ikasan.spec.component.filter.FilterException if the rule cannot be evaluated, for example
* because required payload data is invalid or a lookup fails; normal rejection returns false
*/
public boolean accept(${flowElement.getPropertyValue("fromType")} payload) throws org.ikasan.spec.component.filter.FilterException
{
//@TODO implement your filter rule logic
return true;
}
<#if flowElement.getPropertyValue("configuredResource")?has_content && flowElement.getPropertyValue("configuredResource")>

@Override
public String getConfiguredResourceId() {
return configurationId;
}

@Override
public void setConfiguredResourceId(String id) {
this.configurationId = id;
}
</#if>
<#if flowElement.getPropertyValue("configuration")??>

@Override
public ${flowElement.getPropertyValue("configuration")} getConfiguration() {
return configuration;
}

@Override
public void setConfiguration(${flowElement.getPropertyValue("configuration")} configuration) {
this.configuration = configuration;
}
</#if>
}
